(window.webpackJsonp=window.webpackJsonp||[]).push([[6],{485:function(e,t,s){"use strict";s.r(t);s(107),s(225),s(349),s(350),s(351),s(352),s(353),s(354),s(355),s(356),s(357),s(358),s(359),s(360),s(466),s(417),s(418),s(431),s(361),s(432),s(165),s(433),s(434),s(178),s(435),s(217),s(329),s(467),s(256),s(407),s(423),s(399),s(364),s(218),s(436),s(330),s(409),s(424),s(365),s(237),s(331),s(437),s(257),s(468),s(183),s(201),s(323),s(419),s(403),s(438),s(439),s(440),s(333),s(334),s(441),s(413),s(332),s(442),s(335),s(443),s(469),s(470),s(336),s(219),s(444),s(145),s(414),s(271),s(445),s(227),s(228),s(229),s(235),s(236),s(372);var i=s(58);class n extends i.a{static get template(){return i.b`
            <style include="shared-styles">
                :host {
                    display: block;
                    height: 100%;
                }
            </style>
        `}static get is(){return"main-view"}static get properties(){return{}}}customElements.define(n.is,n)}}]);